describe("photonui.FileManager", function() {

    beforeAll(function() {
        // ...
    });

    beforeEach(function() {
        // ...
    });

    afterEach(function() {
        // ...
    });

    // it("<DESCRIPTION>", function() {
    //     // EXPECTATIONS
    // });

});

