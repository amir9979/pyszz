describe("photonui.ProgressBar", function() {

    beforeAll(function() {
        // ...
    });

    beforeEach(function() {
        // ...
    });

    afterEach(function() {
        // ...
    });

    // it("<DESCRIPTION>", function() {
    //     // EXPECTATIONS
    // });

});

